# Homebrew formula for a tap (github.com/RAZKOM/homebrew-tap,
# file Formula/hem.rb).  Fill in the sha256 values from the release's
# `.sha256` files before publishing.
class Hem < Formula
  desc "Human-readable Event Monitor: a fast terminal log viewer. tail, but tailored"
  homepage "https://github.com/RAZKOM/hem"
  version "0.1.0"
  license any_of: ["MIT", "Apache-2.0"]

  on_macos do
    on_arm do
      url "https://github.com/RAZKOM/hem/releases/download/v#{version}/hem-aarch64-apple-darwin.tar.gz"
      sha256 "0000000000000000000000000000000000000000000000000000000000000000"
    end
    on_intel do
      url "https://github.com/RAZKOM/hem/releases/download/v#{version}/hem-x86_64-apple-darwin.tar.gz"
      sha256 "0000000000000000000000000000000000000000000000000000000000000000"
    end
  end

  on_linux do
    on_arm do
      url "https://github.com/RAZKOM/hem/releases/download/v#{version}/hem-aarch64-unknown-linux-musl.tar.gz"
      sha256 "0000000000000000000000000000000000000000000000000000000000000000"
    end
    on_intel do
      url "https://github.com/RAZKOM/hem/releases/download/v#{version}/hem-x86_64-unknown-linux-musl.tar.gz"
      sha256 "0000000000000000000000000000000000000000000000000000000000000000"
    end
  end

  def install
    bin.install "hem"
  end

  test do
    (testpath/"a.log").write("2026-10-13 10:00:00 ERROR boom\n2026-10-13 10:00:01 INFO ok\n")
    assert_equal "2026-10-13 10:00:00 ERROR boom\n",
                 shell_output("#{bin}/hem #{testpath}/a.log --level error --plain")
    assert_match version.to_s, shell_output("#{bin}/hem --version")
  end
end
